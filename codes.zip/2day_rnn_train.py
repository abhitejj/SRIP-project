import os
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import itertools
from torch.amp import GradScaler, autocast
import random
script_start_time = time.time()
# PARAMETERS
DATA_PATHS = [
    "1981-2022_NH-16-OD_Final.csv",
    "1981-2022_NH-44-Del_Final.csv",
    "1981-2022_NH-44-TN_Final.csv",
    "1981-2022_NH-64-Amd_Final.csv",
    "1981-2022_NH-75-Blr_Final.csv",
    "1981-2022_NH-94-RJ_Final.csv",
    "1981-2022_NH-146-MP_Final.csv",
    "1981-2022_NH-163-Hyd_Final.csv"]
BATCH_SIZE     = 128
EPOCHS_PER_PERM= 3
DEVICE         = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CACHE_DIR      = 'rnn2_cache'
SEQUENCE_LENGTH = 2  # Use only 1 day (previous day) for RNN
os.makedirs(CACHE_DIR, exist_ok=True)

class TempSequenceDataset(torch.utils.data.Dataset):
    def __init__(self, X_seq, X_static, Y):
        self.X_seq = torch.tensor(X_seq, dtype=torch.float32)
        self.X_static = torch.tensor(X_static, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32)
    
    def __len__(self):
        return len(self.X_seq)
    
    def __getitem__(self, i):
        return self.X_seq[i], self.X_static[i], self.Y[i]

class TemperatureRNN(nn.Module):
    def __init__(self, seq_input_size=2, static_input_size=2, hidden_size=10, num_layers=1, output_size=24):
        super().__init__()
        self.rnn = nn.RNN(input_size=seq_input_size, hidden_size=hidden_size, num_layers=num_layers, batch_first=True)
        self.fc1 = nn.Linear(hidden_size + static_input_size, output_size)
        self.tanh = nn.Tanh()
        self.dropout = nn.Dropout(0.1)
    
    def forward(self, seq_x, static_x):
        rnn_out, hidden = self.rnn(seq_x)
        rnn_features = rnn_out[:, -1, :]
        combined = torch.cat([rnn_features, static_x], dim=1)
        out = self.fc1(combined)
        return out
    
def create_sequences(df, sequence_length=2):
    df = df.sort_values('datetime').copy()
    df['date'] = df['datetime'].dt.date
    
    # Create daily temperature profiles
    daily_temps = df.groupby('date')['AirTemp'].agg(['min', 'max']).fillna(0)
    pivot = df.pivot(index='date', columns='Hour', values='AirTemp')
    
    # Add temporal features
    df_daily = df.groupby('date').first().reset_index()
    df_daily['day_of_year'] = pd.to_datetime(df_daily['datetime']).dt.dayofyear
    df_daily['days_in_year'] = pd.to_datetime(df_daily['datetime']).dt.is_leap_year.map({True: 366, False: 365})
    df_daily['doy_sin'] = np.sin(2 * np.pi * df_daily['day_of_year'] / df_daily['days_in_year'])
    df_daily['doy_cos'] = np.cos(2 * np.pi * df_daily['day_of_year'] / df_daily['days_in_year'])
    
    sequences_x, static_x, targets_y = [], [], []
    dates = sorted(pivot.index)
    
    for i in range(sequence_length, len(dates)):
        current_date = dates[i]
        
        # Skip if current day has missing values
        if pivot.loc[current_date].isnull().any():
            continue
            
        # Create sequence of past days (temperature statistics)
        seq_data = []
        valid_sequence = True
        
        for j in range(sequence_length):
            past_date = dates[i - sequence_length + j]
            if past_date not in daily_temps.index:
                valid_sequence = False
                break
            seq_data.append(daily_temps.loc[past_date].values)
        
        if not valid_sequence:
            continue
            
        # Static features for current day
        current_row = df_daily[df_daily['date'] == current_date]
        if len(current_row) == 0:
            continue
            
        static_features = [
            current_row['doy_sin'].iloc[0],
            current_row['doy_cos'].iloc[0]
        ]
        
        # Target: 24-hour temperature profile
        target = pivot.loc[current_date].values.astype(np.float32)
        
        sequences_x.append(seq_data)
        static_x.append(static_features)
        targets_y.append(target)
    
    return np.array(sequences_x), np.array(static_x), np.array(targets_y)



station_data = {}
for path in DATA_PATHS:
    df = pd.read_csv(path)
    df['datetime'] = pd.to_datetime(df[['Year','Month','Day','Hour']])
    station_data[path] = df
random.seed(42)
sampled_perms = random.sample(list(itertools.permutations(DATA_PATHS)), 100)

# --- PERMUTATION-DRIVEN TRAINING WITH CACHE ---
print("Starting training across permutations with caching...")
model = TemperatureRNN().to(DEVICE)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
criterion = nn.MSELoss()
scaler = GradScaler()
station_scalers = {}
latlong_df = pd.read_csv('Lat_long_stations.csv')
station_latlong = {
    row['Station']: (row['Lat'], row['Long'])
    for _, row in latlong_df.iterrows()
}

for path in DATA_PATHS:
    station = os.path.splitext(os.path.basename(path))[0]
    df = station_data[path] 
    seq, stat, tar = create_sequences(df, SEQUENCE_LENGTH)
    n = int(0.8 * len(seq))
    train_seq, train_stat, train_tar = seq[:n], stat[:n], tar[:n]

    # Create and fit scalers on training data
    seq_scaler = StandardScaler().fit(train_seq.reshape(-1,2))
    stat_scaler = StandardScaler().fit(train_stat)
    tar_scaler = StandardScaler().fit(train_tar)
    
    station_scalers[station] = {
        'seq_scaler': seq_scaler,
        'stat_scaler': stat_scaler,
        'tar_scaler': tar_scaler
    }
    scalers_path = os.path.join(CACHE_DIR, f'{station}_scalers_consistent.pkl')
    joblib.dump(station_scalers[station], scalers_path)

for perm_id, perm in enumerate(sampled_perms, 1):
    cache_file = os.path.join(CACHE_DIR, f'perm_{perm_id:03d}.npz')
    if os.path.exists(cache_file):
        # Load cached scaled training data
        data = np.load(cache_file)
        perm_X_seq = data['X_seq']
        perm_X_stat = data['X_stat']
        perm_Y = data['Y']
    else:
        perm_X_seq, perm_X_stat, perm_Y = [], [], []
        station_seq_scalers = {}
        station_stat_scalers = {}
        station_tar_scalers = {}
        for path in perm:
            df = station_data[path]
            station = os.path.splitext(os.path.basename(path))[0]
            seq, stat, tar = create_sequences(df, SEQUENCE_LENGTH)
            n = int(0.8 * len(seq))
            sseq, sstat, star = seq[:n], stat[:n], tar[:n]
             # Use the consistent scalers
            scalers = station_scalers[station]
            perm_X_seq.extend(scalers['seq_scaler'].transform(sseq.reshape(-1,2)).reshape(sseq.shape))
            perm_X_stat.extend(scalers['stat_scaler'].transform(sstat))
            perm_Y.extend(scalers['tar_scaler'].transform(star))
        perm_X_seq = np.array(perm_X_seq)
        perm_X_stat = np.array(perm_X_stat)
        perm_Y = np.array(perm_Y)
        np.savez(cache_file, X_seq=perm_X_seq, X_stat=perm_X_stat, Y=perm_Y)

    dataset = TempSequenceDataset(perm_X_seq, perm_X_stat, perm_Y)
    loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, pin_memory=True, num_workers=4, persistent_workers=True)
    for epoch in range(EPOCHS_PER_PERM):
        model.train()
        for xb, xs, yb in loader:
            xb, xs, yb = xb.to(DEVICE), xs.to(DEVICE), yb.to(DEVICE)
            optimizer.zero_grad()
            with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'):
                preds = model(xb, xs)
                loss = criterion(preds, yb)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

# --- FINAL TEST SET EVALUATION ---
print("\nEvaluating on combined 20% test splits...")
all_preds, all_trues = [], []
for path, df in station_data.items():
    station = os.path.splitext(os.path.basename(path))[0]
    seq, stat, tar = create_sequences(df, SEQUENCE_LENGTH)
    n = int(0.8 * len(seq))
    tseq, tstat, ttar = seq[n:], stat[n:], tar[n:]
    scalers_path = os.path.join(CACHE_DIR, f'{station}_scalers_consistent.pkl')
    if not os.path.exists(scalers_path):
        print(f"Scaler file not found for station {station} at permutation {perm_id}")
        continue
    scalers = joblib.load(scalers_path)
    seq_scaler = scalers['seq_scaler']
    stat_scaler = scalers['stat_scaler']
    targ_scaler = scalers['tar_scaler']
    scaled_seq = seq_scaler.transform(tseq.reshape(-1,2)).reshape(tseq.shape)
    scaled_stat = stat_scaler.transform(tstat)
    preds = []
    ds = TempSequenceDataset(scaled_seq, scaled_stat, np.zeros_like(ttar))
    ld = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=4, pin_memory=True)
    model.eval()
    with torch.no_grad():
        for xb, xs, _ in ld:
            xb, xs = xb.to(DEVICE), xs.to(DEVICE)
            with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'): 
                out = model(xb, xs).cpu().numpy()
            preds.append(out)
    pred_scaled = np.vstack(preds)
    pred_orig = targ_scaler.inverse_transform(pred_scaled)
    all_preds.append(pred_orig)
    all_trues.append(ttar)
    print(f"Station: {station}")
    print("MSE:", mean_squared_error(ttar, pred_orig))
    print("MAE:", mean_absolute_error(ttar, pred_orig))
    print("R2 :", r2_score(ttar, pred_orig))
all_preds = np.vstack(all_preds)
all_trues = np.vstack(all_trues)
print("\nOverall Metrics:")
print("MSE:", mean_squared_error(all_trues, all_preds))
print("MAE:", mean_absolute_error(all_trues, all_preds))
print("R2 :", r2_score(all_trues, all_preds))

# Save model
torch.save(model.state_dict(), 'rnn_temperature_model2.pt')

print(f"\nRNN Features:")
print(f"  - Uses {SEQUENCE_LENGTH} day of temperature history (previous 2 days min/max only)")
print(f"  - Basic RNN with {model.rnn.hidden_size} hidden units, {model.rnn.num_layers} layers")
print(f"  - Total parameters: {sum(p.numel() for p in model.parameters())}")

script_end_time = time.time()
total_execution_time = script_end_time - script_start_time
print("Time taken")
print(f"TOTAL EXECUTION TIME: {time.strftime('%H:%M:%S', time.gmtime(total_execution_time))}")
