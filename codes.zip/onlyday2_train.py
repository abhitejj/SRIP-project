# import os
# import time
# import numpy as np
# import pandas as pd
# import torch
# import torch.nn as nn
# from torch.utils.data import TensorDataset, DataLoader
# from sklearn.preprocessing import StandardScaler
# from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
# import joblib
# import itertools
# from torch.amp import GradScaler, autocast
# import random
# import time
# script_start_time = time.time()
# # PARAMETERS
# DATA_PATHS = [
#     "1981-2022_NH-16-OD_Final.csv",
#     "1981-2022_NH-44-Del_Final.csv",
#     "1981-2022_NH-44-TN_Final.csv",
#     "1981-2022_NH-64-Amd_Final.csv",
#     "1981-2022_NH-75-Blr_Final.csv",
#     "1981-2022_NH-94-RJ_Final.csv",
#     "1981-2022_NH-146-MP_Final.csv",
#     "1981-2022_NH-163-Hyd_Final.csv"]
# BATCH_SIZE     = 128
# EPOCHS_PER_PERM= 3
# DEVICE         = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# LAT_MIN, LAT_MAX = 8.0, 32.0
# LON_MIN, LON_MAX = 68.0, 76.0
# CACHE_DIR      = 'dperm2_cache'
# os.makedirs(CACHE_DIR, exist_ok=True)

# class TempDataset(torch.utils.data.Dataset):
#     def __init__(self, X, Y):
#         self.X = torch.tensor(X, dtype=torch.float32)
#         self.Y = torch.tensor(Y, dtype=torch.float32)
#     def __len__(self): return len(self.X)
#     def __getitem__(self, i): return self.X[i], self.Y[i]

# class SimpleFC2(nn.Module):
#     def __init__(self):
#         super().__init__()
#         self.fc1 = nn.Linear(6, 10)
#         self.tanh = nn.Tanh()
#         self.fc2 = nn.Linear(10, 24)
#     def forward(self, x):
#         return self.fc2(self.tanh(self.fc1(x)))

# #  GLOBAL SCALERS (80% of each station)
# global_feats, global_tgts = [], []
# global_test_feats, global_test_tgts = [], []
# for path in DATA_PATHS:
#     df = pd.read_csv(path)
#     df['datetime'] = pd.to_datetime(df[['Year','Month','Day','Hour']])
#     df.sort_values('datetime', inplace=True)
#     df['date'] = df['datetime'].dt.date
#     df['hour'] = df['datetime'].dt.hour
#     df['day_of_year'] = df['datetime'].dt.dayofyear
#     df['days_in_year'] = df['datetime'].dt.is_leap_year.map({True:366,False:365})
#     df['doy_sin'] = np.sin(2*np.pi*df['day_of_year']/df['days_in_year'])
#     df['doy_cos'] = np.cos(2*np.pi*df['day_of_year']/df['days_in_year'])

#     daily = df.groupby('date')['AirTemp'].agg(min='min', max='max')
#     pivot = df.pivot(index='date', columns='Hour', values='AirTemp')

#     dates = sorted(pivot.index)
#     split_idx = int(0.8 * len(dates))
#     for i, date in enumerate(dates):
#         prev = date - pd.Timedelta(days=1)
#         if prev not in daily.index or date not in daily.index: continue
#         if pivot.loc[date].isnull().any(): continue
#         min_prev, max_prev = daily.loc[prev]
#         min_curr, max_curr = daily.loc[date]
#         row = df[df['date']==date].iloc[0]
#         feat = [min_prev, max_prev, min_curr, max_curr,
#                 row['doy_sin'], row['doy_cos']]
#         tgt  = pivot.loc[date].values.astype(np.float32)
#         global_feats.append(feat)
#         global_tgts.append(tgt)
#         if i >= split_idx: 
#             global_test_feats.append(feat)
#             global_test_tgts.append(tgt)

# X_all = np.vstack(global_feats)
# Y_all = np.vstack(global_tgts)
# feat_scaler = StandardScaler().fit(X_all)
# tgt_scaler  = StandardScaler().fit(Y_all)
# joblib.dump(feat_scaler, os.path.join(CACHE_DIR,'dfeat_scaler2.save'))
# joblib.dump(tgt_scaler,  os.path.join(CACHE_DIR,'dtgt_scaler2.save'))

# # CACHE FUNCTION 
# def cache_perm(perm, perm_id):
#     Xtr, Ytr, Xte, Yte = [], [], [], []
#     for path in perm:
#         df = pd.read_csv(path)
#         df['datetime'] = pd.to_datetime(df[['Year', 'Month', 'Day', 'Hour']])
#         df.sort_values('datetime', inplace=True)
#         df['date'] = df['datetime'].dt.date
#         df['day_of_year'] = df['datetime'].dt.dayofyear
#         df['days_in_year'] = df['datetime'].dt.is_leap_year.map({True: 366, False: 365})
#         df['doy_sin'] = np.sin(2 * np.pi * df['day_of_year'] / df['days_in_year'])
#         df['doy_cos'] = np.cos(2 * np.pi * df['day_of_year'] / df['days_in_year'])
#         daily = df.groupby('date')['AirTemp'].agg(min='min', max='max')
#         pivot = df.pivot(index='date', columns='Hour', values='AirTemp')

#         dates = sorted(pivot.index)
#         split_idx = int(0.8 * len(dates))
#         for i, date in enumerate(dates):
#             prev = date - pd.Timedelta(days=1)
#             if prev not in daily.index or date not in daily.index:
#                 continue
#             if pivot.loc[date].isnull().any():
#                 continue
#             min_prev, max_prev = daily.loc[prev]
#             min_curr, max_curr = daily.loc[date]
#             row = df[df['date'] == date].iloc[0]
#             feat = [min_prev, max_prev, min_curr, max_curr,
#                     row['doy_sin'], row['doy_cos']]
#             tgt = pivot.loc[date].values.astype(np.float32)
#             if i < split_idx:
#                 Xtr.append(feat)
#                 Ytr.append(tgt)
#             else:
#                 Xte.append(feat)
#                 Yte.append(tgt)

#     Xtr, Ytr = np.vstack(Xtr), np.vstack(Ytr)
#     Xte, Yte = np.vstack(Xte), np.vstack(Yte)
#     Xtr_s = feat_scaler.transform(Xtr)
#     Xte_s = feat_scaler.transform(Xte)
#     Ytr_s = tgt_scaler.transform(Ytr)

#     np.savez(os.path.join(CACHE_DIR, f'dperm2_{perm_id:02d}.npz'),
#              Xtr_s=Xtr_s, Ytr_s=Ytr_s, Xte_s=Xte_s, Yte_raw=Yte)

# # TRAIN + TEST ACROSS ALL PERMUTATIONS
# model = SimpleFC2().to(DEVICE)
# optimizer = torch.optim.Adam(model.parameters(), lr=1e-2)
# criterion = nn.MSELoss()

# random.seed(42)
# # Get 50 random permutations out of all possible ones
# perm_list = random.sample(list(itertools.permutations(DATA_PATHS)), 100)

# for perm_id, perm in enumerate(perm_list, start=1):
#     cache_file = os.path.join(CACHE_DIR, f'dperm2_{perm_id:02d}.npz')
#     if not os.path.exists(cache_file):
#         cache_perm(perm, perm_id)

#     data = np.load(cache_file)

#     # Keep tensors on CPU for DataLoader
#     X_train_cpu = torch.tensor(data['Xtr_s'], dtype=torch.float32)  # CPU only
#     Y_train_cpu = torch.tensor(data['Ytr_s'], dtype=torch.float32)  # CPU only
#   # CPU only

#     train_loader = DataLoader(
#         TensorDataset(X_train_cpu, Y_train_cpu), 
#         batch_size=BATCH_SIZE, 
#         shuffle=True, 
#         pin_memory=True,        # Now useful for CPU→GPU transfer
#         num_workers=4, 
#         persistent_workers=True
#         )
#     for epoch in range(1, EPOCHS_PER_PERM + 1):
#         model.train(); tot = 0
#         for xb, yb in train_loader:
#             xb = xb.to(DEVICE, non_blocking=True)  # Move to GPU here
#             yb = yb.to(DEVICE, non_blocking=True)
#             preds = model(xb); loss = criterion(preds, yb)
#             optimizer.zero_grad(); loss.backward(); optimizer.step()
#             tot += loss.item() * xb.size(0)
# X_test = feat_scaler.transform(np.vstack(global_test_feats))
# Y_test = tgt_scaler.transform(np.vstack(global_test_tgts))
# test_loader = DataLoader(
#         TempDataset(X_test, Y_test),
#         batch_size=BATCH_SIZE,
#         shuffle=False,
#         pin_memory=True,
#         num_workers=4
#     )
# model.eval()
# preds, trues = [], []
# with torch.no_grad():
#     for xb, yb in test_loader:
#         xb = xb.to(DEVICE, non_blocking=True)
#         with autocast(device_type='cuda'):
#             p = model(xb).cpu().numpy()
#         preds.append(p)
#         trues.append(yb.numpy())
# preds = np.vstack(preds)
# trues = np.vstack(trues)
# p_o = tgt_scaler.inverse_transform(preds)
# t_o = tgt_scaler.inverse_transform(trues)
# print(f"Validation result on 20% of data")
# print(f"  MSE: {mean_squared_error(t_o, p_o):.4f}")
# print(f"  MAE: {mean_absolute_error(t_o, p_o):.4f}")
# print(f"  R2 : {r2_score(t_o, p_o):.4f}")

# torch.save(model.state_dict(), 'dfast_spatio2_allepochs.pt')
# print("Done continuous training across all permutations.")
# script_end_time = time.time()
# total_execution_time = script_end_time - script_start_time
# print("Time taken")
# print(f"TOTAL EXECUTION TIME: {time.strftime('%H:%M:%S', time.gmtime(total_execution_time))}")

import os
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import itertools
from torch.amp import GradScaler, autocast
import random
import time
script_start_time = time.time()
# PARAMETERS
DATA_PATHS = [
    "1981-2022_NH-16-OD_Final.csv",
    "1981-2022_NH-44-Del_Final.csv",
    "1981-2022_NH-44-TN_Final.csv",
    "1981-2022_NH-64-Amd_Final.csv",
    "1981-2022_NH-75-Blr_Final.csv",
    "1981-2022_NH-94-RJ_Final.csv",
    "1981-2022_NH-146-MP_Final.csv",
    "1981-2022_NH-163-Hyd_Final.csv"]
BATCH_SIZE     = 128
EPOCHS_PER_PERM= 3
DEVICE         = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CACHE_DIR      = 'dperm2_cache'
os.makedirs(CACHE_DIR, exist_ok=True)

class TempDataset(torch.utils.data.Dataset):
    def __init__(self, X, Y=None):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32) if Y is not None else None
    def __len__(self): return len(self.X)
    def __getitem__(self, i):
        if self.Y is None:
            return self.X[i]
        return self.X[i], self.Y[i]

class SimpleFC2(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(6, 10)
        self.tanh = nn.Tanh()
        self.fc2 = nn.Linear(10, 24)
    def forward(self, x):
        return self.fc2(self.tanh(self.fc1(x)))
    
for path in DATA_PATHS:
    df = pd.read_csv(path)
    df['datetime'] = pd.to_datetime(df[['Year','Month','Day','Hour']])
    df.sort_values('datetime', inplace=True)
    df['date'] = df['datetime'].dt.date
    df['day_of_year'] = df['datetime'].dt.dayofyear
    df['days_in_year'] = df['datetime'].dt.is_leap_year.map({True:366,False:365})
    df['doy_sin'] = np.sin(2*np.pi*df['day_of_year']/df['days_in_year'])
    df['doy_cos'] = np.cos(2*np.pi*df['day_of_year']/df['days_in_year'])

    daily = df.groupby('date')['AirTemp'].agg(min='min', max='max')
    pivot = df.pivot(index='date', columns='Hour', values='AirTemp').dropna()

    feats = []
    tgts  = []
    dates = sorted(pivot.index)
    for date in dates:
        prev = date - pd.Timedelta(days=1)
        if prev not in daily.index or date not in daily.index:
            continue
        if pivot.loc[date].isnull().any():
            continue
        min_prev, max_prev = daily.loc[prev]
        min_curr, max_curr = daily.loc[date]
        row = df[df['date']==date].iloc[0]
        feat = [min_prev, max_prev, min_curr, max_curr, row['doy_sin'], row['doy_cos']]
        tgt  = pivot.loc[date].values.astype(np.float32)
        feats.append(feat)
        tgts.append(tgt)

    feats = np.array(feats)
    tgts  = np.array(tgts)

    station = os.path.splitext(os.path.basename(path))[0]
    feat_scaler = StandardScaler().fit(feats)
    tgt_scaler  = StandardScaler().fit(tgts)
    joblib.dump({'feats': feats, 'tgts': tgts}, os.path.join(CACHE_DIR, f'{station}_daily.pkl'))
    joblib.dump(feat_scaler, os.path.join(CACHE_DIR, f'{station}_feat_scaler.save'))
    joblib.dump(tgt_scaler,  os.path.join(CACHE_DIR, f'{station}_tgt_scaler.save'))

# CACHE FUNCTION 
def cache_perm(perm, perm_id):
    Xtr, Ytr, Xte, Yte = [], [], [], []
    for path in perm:
        station = os.path.splitext(os.path.basename(path))[0]
        # load cached daily + scalers
        cached = joblib.load(os.path.join(CACHE_DIR, f'{station}_daily.pkl'))
        feats = cached['feats']
        tgts  = cached['tgts']
        feat_scaler = joblib.load(os.path.join(CACHE_DIR, f'{station}_feat_scaler.save'))
        tgt_scaler  = joblib.load(os.path.join(CACHE_DIR, f'{station}_tgt_scaler.save'))

        n = int(0.8 * len(feats))
        X_train, X_test = feats[:n], feats[n:]
        Y_train, Y_test = tgts[:n],  tgts[n:]

        Xtr.extend(feat_scaler.transform(X_train))
        Ytr.extend(tgt_scaler.transform(Y_train))
        Xte.extend(feat_scaler.transform(X_test))
        # save raw for later inverse
        Yte.extend(Y_test)

    Xtr = np.vstack(Xtr)
    Ytr = np.vstack(Ytr)
    Xte = np.vstack(Xte)
    Yte = np.vstack(Yte)

    np.savez(os.path.join(CACHE_DIR, f'dperm2_{perm_id:02d}.npz'),
             Xtr_s=Xtr, Ytr_s=Ytr, Xte_s=Xte, Yte_raw=Yte)

# TRAIN + TEST ACROSS ALL PERMUTATIONS
model = SimpleFC2().to(DEVICE)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-2)
criterion = nn.MSELoss()
scaler    = GradScaler()
random.seed(42)
perm_list = random.sample(list(itertools.permutations(DATA_PATHS)), 50)

for perm_id, perm in enumerate(perm_list, start=1):
    cache_file = os.path.join(CACHE_DIR, f'dperm2_{perm_id:02d}.npz')
    if not os.path.exists(cache_file):
        cache_perm(perm, perm_id)

    data = np.load(cache_file)

    # Keep tensors on CPU for DataLoader
    X_train_cpu = torch.tensor(data['Xtr_s'], dtype=torch.float32)  # CPU only
    Y_train_cpu = torch.tensor(data['Ytr_s'], dtype=torch.float32)  # CPU only
  # CPU only

    train_loader = DataLoader(
        TensorDataset(X_train_cpu, Y_train_cpu), 
        batch_size=BATCH_SIZE, 
        shuffle=True, 
        pin_memory=True,      
        num_workers=4, 
        persistent_workers=True
        )
    for epoch in range(1, EPOCHS_PER_PERM + 1):
        model.train(); tot = 0
        for xb, yb in train_loader:
            xb = xb.to(DEVICE, non_blocking=True)  
            yb = yb.to(DEVICE, non_blocking=True)
            optimizer.zero_grad()
            with autocast(device_type='cuda'):
                pred = model(xb)
                loss = criterion(pred, yb)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
#validation
all_preds, all_trues = [], []
for path in DATA_PATHS:
    station = os.path.splitext(os.path.basename(path))[0]
 
    cached = joblib.load(os.path.join(CACHE_DIR, f'{station}_daily.pkl'))
    feats = cached['feats']
    tgts  = cached['tgts']
    feat_scaler = joblib.load(os.path.join(CACHE_DIR, f'{station}_feat_scaler.save'))
    tgt_scaler  = joblib.load(os.path.join(CACHE_DIR, f'{station}_tgt_scaler.save'))
    n = int(0.8 * len(feats))
    X_test = feats[n:]
    Y_true = tgts[n:]

    Xs = feat_scaler.transform(X_test)
    val_ds = TempDataset(Xs)
    val_dl = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, pin_memory=True, num_workers=4)

    # predict
    preds_s = []
    model.eval()
    with torch.no_grad():
        for xb in val_dl:
            xb = xb.to(DEVICE)
            out = model(xb).cpu().numpy()
            preds_s.append(out)
    preds_s = np.vstack(preds_s)
    preds = tgt_scaler.inverse_transform(preds_s)

    # collect
    all_preds.append(preds)
    all_trues.append(Y_true)

    # station metrics
    mse = mean_squared_error(Y_true, preds)
    mae = mean_absolute_error(Y_true, preds)
    r2  = r2_score(Y_true, preds)
    print(f"Station: {station}")
    print(f"  MSE: {mse:.4f}")
    print(f"  MAE: {mae:.4f}")
    print(f"  R2 : {r2:.4f}")

# overall metrics
all_preds_arr = np.vstack(all_preds)
all_trues_arr = np.vstack(all_trues)
print("Overall Metrics:")
print(f"  MSE: {mean_squared_error(all_trues_arr, all_preds_arr):.4f}")
print(f"  MAE: {mean_absolute_error(all_trues_arr, all_preds_arr):.4f}")
print(f"  R2 : {r2_score(all_trues_arr, all_preds_arr):.4f}")

torch.save(model.state_dict(), 'dfast2_train.pt')
print("Done continuous training across all permutations.")
script_end_time = time.time()
total_execution_time = script_end_time - script_start_time
print("Time taken")
print(f"TOTAL EXECUTION TIME: {time.strftime('%H:%M:%S', time.gmtime(total_execution_time))}")

