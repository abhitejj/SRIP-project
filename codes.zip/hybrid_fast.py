import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import itertools
import random
import time
from torch.amp import autocast

script_start_time = time.time()

DATA_PATHS = [
    "1981-2022_NH-16-OD_Final.csv",
    "1981-2022_NH-64-Nepal_Final.csv",
    "1981-2022_NH-44-TN_Final.csv",
    "1981-2022_NH-64-Amd_Final.csv",
    "1981-2022_NH-75-Blr_Final.csv",
    "1981-2022_NH-94-RJ_Final.csv",
    "1981-2022_NH-146-MP_Final.csv",
    "1981-2022_EEH-Mum_Final.csv",
    "1981-2022_NH-64-Nepal_Final.csv"
]
BATCH_SIZE = 128
EPOCHS_PER_PERM = 3
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CACHE_DIR = 'hybrid_cache1'

os.makedirs(CACHE_DIR, exist_ok=True)

# Model definition
class RNNModel(nn.Module):
    def __init__(self, input_size=6, hidden_size=10, num_layers=1):
        super().__init__()
        self.rnn = nn.RNN(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, 24)

    def forward(self, x):
        x = x.unsqueeze(1)  # [B, 1, 6]
        out, _ = self.rnn(x)
        return self.fc(out[:, -1, :])

# Utility
def get_station_name(path):
    return os.path.splitext(os.path.basename(path))[0]

# 1) Load & preprocess each station once
# 2) Precompute daily aggregates & pivot

print("Loading and preprocessing all stations data...")
station_data = {}
for path in DATA_PATHS:
    name = get_station_name(path)
    df = pd.read_csv(path)
    df['datetime'] = pd.to_datetime(df[['Year','Month','Day','Hour']])
    df.sort_values('datetime', inplace=True)
    df['date'] = df['datetime'].dt.date
    df['hour'] = df['datetime'].dt.hour
    df['day_of_year'] = df['datetime'].dt.dayofyear
    df['days_in_year'] = df['datetime'].dt.is_leap_year.map({True:366,False:365})
    df['doy_sin'] = np.sin(2*np.pi*df['day_of_year']/df['days_in_year'])
    df['doy_cos'] = np.cos(2*np.pi*df['day_of_year']/df['days_in_year'])
    daily = df.groupby('date')['AirTemp'].agg(min='min', max='max')
    pivot = df.pivot(index='date', columns='Hour', values='AirTemp')
    station_data[name] = {
        'df': df,
        'daily': daily,
        'pivot': pivot,
        'dates': sorted(pivot.index)
    }
print("Preprocessing complete.")

# Create station-specific scalers
# print("Creating station-specific scalers")
station_scalers = {}
for name, data in station_data.items():
    feats, tgts = [], []
    prev_min, prev_max = 0.0, 0.0
    for date in data['dates']:
        if data['pivot'].loc[date].isnull().any():
            continue
        min_c, max_c = data['daily'].loc[date]
        row = data['df'][data['df']['date']==date].iloc[0]
        feat = [min_c, max_c, prev_min, prev_max, row['doy_sin'], row['doy_cos']]
        tgt = data['pivot'].loc[date].values.astype(np.float32)
        feats.append(feat)
        tgts.append(tgt)
        prev_min, prev_max = tgt.min(), tgt.max()
    X = np.vstack(feats)
    Y = np.vstack(tgts)
    feat_scaler = StandardScaler().fit(X)
    tgt_scaler = StandardScaler().fit(Y)
    station_scalers[name] = {'feat_scaler': feat_scaler, 'tgt_scaler': tgt_scaler}
    joblib.dump(feat_scaler, os.path.join(CACHE_DIR, f'{name}_feat_scaler.save'))
    joblib.dump(tgt_scaler, os.path.join(CACHE_DIR, f'{name}_tgt_scaler.save'))
# print("Station-specific scalers created and saved.")

# Initial warm-up training on first station
print("Training initial model warm-up")
model = RNNModel().to(DEVICE)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-2)
criterion = nn.MSELoss()
first_name = get_station_name(DATA_PATHS[0])
data0 = station_data[first_name]
# Build training arrays for first station
dates0 = data0['dates']
split0 = int(0.8*len(dates0))
X0, Y0 = [], []
prev_min, prev_max = 0.0, 0.0
for i, date in enumerate(dates0[:split0]):
    if data0['pivot'].loc[date].isnull().any(): continue
    min_c, max_c = data0['daily'].loc[date]
    row = data0['df'][data0['df']['date']==date].iloc[0]
    feat = [min_c, max_c, prev_min, prev_max, row['doy_sin'], row['doy_cos']]
    tgt = data0['pivot'].loc[date].values.astype(np.float32)
    X0.append(feat); Y0.append(tgt)
    prev_min, prev_max = tgt.min(), tgt.max()
X0 = station_scalers[first_name]['feat_scaler'].transform(np.vstack(X0))
Y0 = station_scalers[first_name]['tgt_scaler'].transform(np.vstack(Y0))
train_loader0 = DataLoader(TensorDataset(torch.tensor(X0, dtype=torch.float32), torch.tensor(Y0, dtype=torch.float32)), batch_size=BATCH_SIZE, shuffle=False)
for epoch in range(5):
    model.train()
    for xb, yb in train_loader0:
        xb, yb = xb.to(DEVICE), yb.to(DEVICE)
        with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'):
            preds = model(xb)
            loss = criterion(preds, yb)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
print("Initial model trained.")

# Function to cache permutations with predictions

def cache_perm_with_predictions(perm, perm_id, model):
    Xtr, Ytr, Xte, Yte = [], [], [], []
    station_info = []
    for path in perm:
        name = get_station_name(path)
        data = station_data[name]
        dates = data['dates']
        split = int(0.8*len(dates))
        prev_min, prev_max = 0.0, 0.0
        for i, date in enumerate(dates):
            if data['pivot'].loc[date].isnull().any(): continue
            min_c, max_c = data['daily'].loc[date]
            row = data['df'][data['df']['date']==date].iloc[0]
            feat = [min_c, max_c, prev_min, prev_max, row['doy_sin'], row['doy_cos']]
            tgt = data['pivot'].loc[date].values.astype(np.float32)
            if i < split:
                Xtr.append(feat); Ytr.append(tgt); station_info.append(('train', name))
            else:
                Xte.append(feat); Yte.append(tgt); station_info.append(('test', name))
            # predict for next day
            if i < len(dates)-1:
                fs = station_scalers[name]['feat_scaler']
                ts = station_scalers[name]['tgt_scaler']
                inp = fs.transform([feat])
                with torch.no_grad():
                    model.eval()
                    pred_s = model(torch.tensor(inp, dtype=torch.float32).to(DEVICE)).cpu().numpy()
                pred = ts.inverse_transform(pred_s)
                prev_min, prev_max = pred.min(), pred.max()
            else:
                prev_min, prev_max = (0.0, 0.0) if i==0 else (tgt.min(), tgt.max())
    # scale and save
    Xtr_s, Ytr_s, Xte_s, Yte_r = [], [], [], []
    ti = tr = 0
    for split_type, name in station_info:
        fs, ts = station_scalers[name]['feat_scaler'], station_scalers[name]['tgt_scaler']
        if split_type=='train':
            Xtr_s.append(fs.transform([Xtr[ti]])[0]); Ytr_s.append(ts.transform([Ytr[ti]])[0]); ti+=1
        else:
            Xte_s.append(fs.transform([Xte[tr]])[0]); Yte_r.append(Yte[tr]); tr+=1
    np.savez(os.path.join(CACHE_DIR, f'rperm_{perm_id:02d}.npz'),
             Xtr_s=np.vstack(Xtr_s), Ytr_s=np.vstack(Ytr_s),
             Xte_s=np.vstack(Xte_s), Yte_raw=np.vstack(Yte_r),
             station_info=station_info)

# Permutation training
print("Starting permutation training...")
random.seed(42)
perm_list = random.sample(list(itertools.permutations(DATA_PATHS)), 50)
for pid, perm in enumerate(perm_list, 1):
    print(f"Processing permutation {pid}/50")
    cache_perm_with_predictions(perm, pid, model)
    data = np.load(os.path.join(CACHE_DIR, f'rperm_{pid:02d}.npz'), allow_pickle=True)
    Xtr = torch.tensor(data['Xtr_s'], dtype=torch.float32)
    Ytr = torch.tensor(data['Ytr_s'], dtype=torch.float32)
    loader = DataLoader(TensorDataset(Xtr, Ytr), batch_size=BATCH_SIZE, shuffle=False)
    for epoch in range(EPOCHS_PER_PERM):
        model.train()
        for xb, yb in loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'):
                preds = model(xb)
                loss = criterion(preds, yb)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

# Final evaluation
print("Performing final evaluation...")
all_preds, all_trues = [], []
for name, data in station_data.items():
    dates = data['dates']; split = int(0.8*len(dates))
    feats, tgts = [], []
    prev_min, prev_max = 0.0, 0.0
    for i, date in enumerate(dates):
        if data['pivot'].loc[date].isnull().any(): continue
        min_c, max_c = data['daily'].loc[date]
        row = data['df'][data['df']['date']==date].iloc[0]
        feat = [min_c, max_c, prev_min, prev_max, row['doy_sin'], row['doy_cos']]
        tgt = data['pivot'].loc[date].values.astype(np.float32)
        if i>=split: feats.append(feat); tgts.append(tgt)
        prev_min, prev_max = tgt.min(), tgt.max()
    if feats:
        Xs = station_scalers[name]['feat_scaler'].transform(np.vstack(feats))
        Ys = station_scalers[name]['tgt_scaler'].transform(np.vstack(tgts))
        loader = DataLoader(TensorDataset(torch.tensor(Xs, dtype=torch.float32), torch.tensor(Ys, dtype=torch.float32)), batch_size=BATCH_SIZE, shuffle=False, pin_memory=True)
        preds, trues = [], []
        model.eval()
        with torch.no_grad():
            for xb, yb in loader:
                xb = xb.to(DEVICE)
                with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'):
                    p = model(xb).cpu().numpy()
                preds.append(p)
                trues.append(yb.numpy())
        p_all = np.vstack(preds); t_all = np.vstack(trues)
        p_orig = station_scalers[name]['tgt_scaler'].inverse_transform(p_all)
        t_orig = station_scalers[name]['tgt_scaler'].inverse_transform(t_all)
        all_preds.append(p_orig); all_trues.append(t_orig)
        mse = mean_squared_error(t_orig, p_orig)
        mae = mean_absolute_error(t_orig, p_orig)
        r2  = r2_score(t_orig, p_orig)
        print(f"Station {name} - MSE:{mse:.4f} MAE:{mae:.4f} R2:{r2:.4f}")
if all_preds:
    p_o = np.vstack(all_preds); t_o = np.vstack(all_trues)
    print("\nOverall validation:")
    print(f" MSE:{mean_squared_error(t_o,p_o):.4f} MAE:{mean_absolute_error(t_o,p_o):.4f} R2:{r2_score(t_o,p_o):.4f}")

torch.save(model.state_dict(), 'hybrid_rnn1.pt')
print("Done. Total time:", time.strftime('%H:%M:%S', time.gmtime(time.time()-script_start_time)))
