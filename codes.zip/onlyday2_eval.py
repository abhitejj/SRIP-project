import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt
from torch.amp import autocast

CSV_PATH    = ["1981-2022_EEH-Mum_Final.csv","1981-2022_NH-64-Nepal_Final.csv"]
MODEL_PATH  = "dfast2_train.pt"
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
class TempDataset(torch.utils.data.Dataset):
    def __init__(self, X, Y=None):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32) if Y is not None else None
    def __len__(self): return len(self.X)
    def __getitem__(self, i):
        if self.Y is None:
            return self.X[i]
        return self.X[i], self.Y[i]

class SimpleFC2(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(6, 10)
        self.tanh = nn.Tanh()
        self.fc2 = nn.Linear(10, 24)
    def forward(self, x):
        return self.fc2(self.tanh(self.fc1(x)))

model = SimpleFC2().to(DEVICE)
model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE, weights_only=True))
model.eval()
all_preds_total = []
all_trues_total = []
for path in CSV_PATH:
# LOAD DATA
    df = pd.read_csv(path)
    df['datetime'] = pd.to_datetime(df[['Year','Month','Day','Hour']])
    df = df.sort_values('datetime').reset_index(drop=True)
    df['date'] = df['datetime'].dt.date
    df['hour'] = df['datetime'].dt.hour
    df['day_of_year'] = df['datetime'].dt.dayofyear
    df['days_in_year'] = df['datetime'].dt.is_leap_year.map({True:366, False:365})
    df['doy_sin'] = np.sin(2 * np.pi * df['day_of_year'] / df['days_in_year'])
    df['doy_cos'] = np.cos(2 * np.pi * df['day_of_year'] / df['days_in_year'])

    daily = df.groupby('date')['AirTemp'].agg(min='min', max='max')
    pivot = df.pivot(index='date', columns='hour', values='AirTemp')

    X_list, Y_list = [], []
    for date, hourly in pivot.iterrows():
        prev = date - pd.Timedelta(days=1)
        if prev not in daily.index or date not in daily.index:
            continue
        if hourly.isnull().any():
            continue
        min_prev, max_prev = daily.loc[prev]
        min_curr, max_curr = daily.loc[date]
        row = df[df['date']==date].iloc[0]
        feat = [min_prev, max_prev, min_curr, max_curr, row['doy_sin'], row['doy_cos']]
        X_list.append(feat)
        Y_list.append(hourly.values.astype(np.float32))

    X = np.vstack(X_list)
    Y_true = np.vstack(Y_list)
    feat_scaler = StandardScaler().fit(X)
    X_scaled = feat_scaler.transform(X)
    tgt_scaler = StandardScaler().fit(Y_true)
    Y_scaled = tgt_scaler.transform(Y_true)
    ds = TempDataset(X_scaled, Y_scaled)
    loader = DataLoader(ds, batch_size=64, shuffle=False, pin_memory=True, num_workers=4)
    all_preds_scaled = []
    all_trues_scaled = []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(DEVICE)
            with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'):
                preds = model(xb).cpu().numpy()
            all_preds_scaled.append(preds)
            all_trues_scaled.append(yb.numpy())

    all_preds_scaled = np.vstack(all_preds_scaled)
    all_trues_scaled  = np.vstack(all_trues_scaled)
    preds = tgt_scaler.inverse_transform(all_preds_scaled)
    trues = tgt_scaler.inverse_transform(all_trues_scaled)
    all_preds_total.append(preds)
    all_trues_total.append(trues)
    mse = mean_squared_error(trues, preds)
    mae = mean_absolute_error(trues, preds)
    r2  = r2_score(trues, preds)
    station_id = path.split('_')[-1].split('.')[0] 
    print(f"\nStation: {station_id}")
    print(f"  MSE: {mse:.4f}")
    print(f"  MAE: {mae:.4f}")
    print(f"  R²:  {r2:.4f}")
#print overall results
all_p = np.vstack(all_preds_total)
all_t = np.vstack(all_trues_total)
print("\nOverall Metrics:")
print(" MSE:", f"{mean_squared_error(all_t, all_p):.4f}")
print(" MAE:", f"{mean_absolute_error(all_t, all_p):.4f}")
print(" R2 :", f"{r2_score(all_t, all_p):.4f}")