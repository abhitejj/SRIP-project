
import os
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import itertools
from torch.amp import GradScaler, autocast
import random
script_start_time = time.time()
# --- PARAMETERS ---
DATA_PATHS = [
    "1981-2022_NH-16-OD_Final.csv",
    "1981-2022_NH-44-Del_Final.csv",
    "1981-2022_NH-44-TN_Final.csv",
    "1981-2022_NH-64-Amd_Final.csv",
    "1981-2022_NH-75-Blr_Final.csv",
    "1981-2022_NH-94-RJ_Final.csv",
    "1981-2022_EEH-Mum_Final.csv",
    "1981-2022_NH-64-Nepal_Final.csv"   
]
BATCH_SIZE = 128
EPOCHS_PER_PERM = 3
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CACHE_DIR = 'rnn1_cache'
SEQUENCE_LENGTH = 1
os.makedirs(CACHE_DIR, exist_ok=True)

# --- DATASET ---
class TempSequenceDataset(torch.utils.data.Dataset):
    def __init__(self, X_seq, X_static, Y):
        self.X_seq = torch.tensor(X_seq, dtype=torch.float32)
        self.X_static = torch.tensor(X_static, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32)
    def __len__(self): return len(self.X_seq)
    def __getitem__(self, i): return self.X_seq[i], self.X_static[i], self.Y[i]

# --- MODEL ---
class TemperatureRNN(nn.Module):
    def __init__(self, seq_input_size=2, static_input_size=2, hidden_size=10, num_layers=1, output_size=24):
        super().__init__()
        self.rnn = nn.RNN(seq_input_size, hidden_size, num_layers,
                          batch_first=True, dropout=0.2 if num_layers>1 else 0)
        self.fc1 = nn.Linear(hidden_size + static_input_size, output_size)
    def forward(self, seq_x, static_x):
        rnn_out, _ = self.rnn(seq_x)
        features = rnn_out[:, -1, :]
        combined = torch.cat([features, static_x], dim=1)
        return self.fc1(combined)

# --- SEQUENCE CREATION ---
def create_sequences(df, sequence_length=1):
    df = df.sort_values('datetime').copy()
    df['date'] = df['datetime'].dt.date
    daily = df.groupby('date')['AirTemp'].agg(['min','max']).fillna(0)
    pivot = df.pivot(index='date', columns='Hour', values='AirTemp')
    df_daily = df.groupby('date').first().reset_index()
    df_daily['day_of_year'] = df_daily['datetime'].dt.dayofyear
    df_daily['days_in_year'] = df_daily['datetime'].dt.is_leap_year.map({True:366,False:365})
    df_daily['doy_sin'] = np.sin(2*np.pi*df_daily['day_of_year']/df_daily['days_in_year'])
    df_daily['doy_cos'] = np.cos(2*np.pi*df_daily['day_of_year']/df_daily['days_in_year'])
    seqs, stats, tars = [], [], []
    dates = sorted(pivot.index)
    for i in range(sequence_length, len(dates)):
        d = dates[i]
        if pivot.loc[d].isnull().any(): continue
        seq, valid = [], True
        for j in range(sequence_length):
            pd0 = dates[i-sequence_length+j]
            if pd0 not in daily.index:
                valid=False; break
            seq.append(daily.loc[pd0].values)
        if not valid: continue
        row = df_daily[df_daily['date']==d]
        if row.empty: continue
        stats.append([row['doy_sin'].iloc[0], row['doy_cos'].iloc[0]])
        seqs.append(seq)
        tars.append(pivot.loc[d].values.astype(np.float32))
    return np.array(seqs), np.array(stats), np.array(tars)

# --- LOAD STATION DATA ---
station_data = {}
for path in DATA_PATHS:
    df = pd.read_csv(path)
    df['datetime'] = pd.to_datetime(df[['Year','Month','Day','Hour']])
    station_data[path] = df

# --- SAMPLE PERMUTATIONS ---
random.seed(42)
sampled_perms = random.sample(list(itertools.permutations(DATA_PATHS)), 100)

# --- PERMUTATION-DRIVEN TRAINING WITH CACHE ---
print("Starting training across permutations with caching...")
model = TemperatureRNN().to(DEVICE)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
criterion = nn.MSELoss()
scaler = GradScaler()
station_scalers = {}
latlong_df = pd.read_csv('Lat_long_stations.csv')
station_latlong = {
    row['Station']: (row['Lat'], row['Long'])
    for _, row in latlong_df.iterrows()
}
for path in DATA_PATHS:
    station = os.path.splitext(os.path.basename(path))[0]
    df = station_data[path] 
    seq, stat, tar = create_sequences(df, SEQUENCE_LENGTH)
    n = int(0.8 * len(seq))
    train_seq, train_stat, train_tar = seq[:n], stat[:n], tar[:n]

    # Create and fit scalers on training data
    seq_scaler = StandardScaler().fit(train_seq.reshape(-1,2))
    stat_scaler = StandardScaler().fit(train_stat)
    tar_scaler = StandardScaler().fit(train_tar)
    
    station_scalers[station] = {
        'seq_scaler': seq_scaler,
        'stat_scaler': stat_scaler,
        'tar_scaler': tar_scaler
    }
    scalers_path = os.path.join(CACHE_DIR, f'{station}_scalers_consistent.pkl')
    joblib.dump(station_scalers[station], scalers_path)
    print(f"Saved consistent scalers for station {station}")
for perm_id, perm in enumerate(sampled_perms, 1):
    cache_file = os.path.join(CACHE_DIR, f'perm_{perm_id:03d}.npz')
    if os.path.exists(cache_file):
        # Load cached scaled training data
        data = np.load(cache_file)
        perm_X_seq = data['X_seq']
        perm_X_stat = data['X_stat']
        perm_Y = data['Y']
    else:
        perm_X_seq, perm_X_stat, perm_Y = [], [], []
        station_seq_scalers = {}
        station_stat_scalers = {}
        station_tar_scalers = {}
        for path in perm:
            df = station_data[path]
            station = os.path.splitext(os.path.basename(path))[0]
            seq, stat, tar = create_sequences(df, SEQUENCE_LENGTH)
            n = int(0.8 * len(seq))
            sseq, sstat, star = seq[:n], stat[:n], tar[:n]
             # Use the consistent scalers
            scalers = station_scalers[station]
            perm_X_seq.extend(scalers['seq_scaler'].transform(sseq.reshape(-1,2)).reshape(sseq.shape))
            perm_X_stat.extend(scalers['stat_scaler'].transform(sstat))
            perm_Y.extend(scalers['tar_scaler'].transform(star))
        perm_X_seq = np.array(perm_X_seq)
        perm_X_stat = np.array(perm_X_stat)
        perm_Y = np.array(perm_Y)
        np.savez(cache_file, X_seq=perm_X_seq, X_stat=perm_X_stat, Y=perm_Y)

    dataset = TempSequenceDataset(perm_X_seq, perm_X_stat, perm_Y)
    loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, pin_memory=True, num_workers=4, persistent_workers=True)
    for epoch in range(EPOCHS_PER_PERM):
        model.train()
        for xb, xs, yb in loader:
            xb, xs, yb = xb.to(DEVICE), xs.to(DEVICE), yb.to(DEVICE)
            optimizer.zero_grad()
            with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'):
                preds = model(xb, xs)
                loss = criterion(preds, yb)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

# --- FINAL TEST SET EVALUATION ---
print("\nEvaluating on combined 20% test splits...")
all_preds, all_trues = [], []
for path, df in station_data.items():
    station_name = os.path.splitext(os.path.basename(path))[0]
    seq, stat, tar = create_sequences(df, SEQUENCE_LENGTH)
    n = int(0.8 * len(seq))
    tseq, tstat, ttar = seq[n:], stat[n:], tar[n:]
    scalers_path = os.path.join(CACHE_DIR, f'{station}_scalers_consistent.pkl')
    if not os.path.exists(scalers_path):
        print(f"Scaler file not found for station {station} at permutation {perm_id}")
        continue
    scalers = joblib.load(scalers_path)
    seq_scaler = scalers['seq_scaler']
    stat_scaler = scalers['stat_scaler']
    targ_scaler = scalers['tar_scaler']
    scaled_seq = seq_scaler.transform(tseq.reshape(-1,2)).reshape(tseq.shape)
    scaled_stat = stat_scaler.transform(tstat)
    preds = []
    ds = TempSequenceDataset(scaled_seq, scaled_stat, np.zeros_like(ttar))
    ld = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=4, pin_memory=True)
    model.eval()
    with torch.no_grad():
        for xb, xs, _ in ld:
            xb, xs = xb.to(DEVICE), xs.to(DEVICE)
            with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'): 
                out = model(xb, xs).cpu().numpy()
            preds.append(out)
    pred_scaled = np.vstack(preds)
    pred_orig = targ_scaler.inverse_transform(pred_scaled)
    all_preds.append(pred_orig)
    all_trues.append(ttar)
    print(f"Station: {station_name}")
    print("MSE:", mean_squared_error(ttar, pred_orig))
    print("MAE:", mean_absolute_error(ttar, pred_orig))
    print("R2 :", r2_score(ttar, pred_orig))
all_preds = np.vstack(all_preds)
all_trues = np.vstack(all_trues)
print("\nOverall Metrics:")
print("MSE:", mean_squared_error(all_trues, all_preds))
print("MAE:", mean_absolute_error(all_trues, all_preds))
print("R2 :", r2_score(all_trues, all_preds))

torch.save(model.state_dict(), 'rnn_temperature_model1.pt')

script_end_time = time.time()
total_execution_time = script_end_time - script_start_time
print("Time taken")
print(f"TOTAL EXECUTION TIME: {time.strftime('%H:%M:%S', time.gmtime(total_execution_time))}")


