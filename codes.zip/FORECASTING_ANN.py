
# import os
# import numpy as np
# import pandas as pd
# import torch
# import torch.nn as nn
# import joblib

# # ---- SETTINGS ----
# FUTURE_CSV      = "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Hyderabad.csv"
# CACHE_DIR       = "dperm_cache"
# MODEL_PATH      = "dfast_train.pt"
# OUTPUT_CSV      = "Future predicted data/Aus model/future_hourly_preds_ssp585_Hyderabad(Aus).csv"
# DEVICE          = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# STATION_NAME    = "1981-2022_NH-163-Hyd_Final"

# # ---- MODEL DEFINITION ----
# class SimpleFC(nn.Module):
#     def __init__(self):
#         super().__init__()
#         self.fc1 = nn.Linear(4, 10)
#         self.tanh = nn.Tanh()
#         self.fc2 = nn.Linear(10, 24)
#     def forward(self, x):
#         return self.fc2(self.tanh(self.fc1(x)))

# # ---- LOAD & PREPROCESS FUTURE DAILY DATA ----
# df = pd.read_csv(FUTURE_CSV, usecols=["Year","Month","Day","tasmax","tasmin"])
# df["date"]         = pd.to_datetime(df[["Year","Month","Day"]]).dt.date
# df["day_of_year"]  = pd.to_datetime(df["date"]).dt.dayofyear
# df["days_in_year"] = pd.to_datetime(df["date"]).dt.is_leap_year.map({True:366, False:365})
# df["doy_sin"] = np.sin(2*np.pi * df["day_of_year"] / df["days_in_year"])
# df["doy_cos"] = np.cos(2*np.pi * df["day_of_year"] / df["days_in_year"])
# df.rename(columns={"tasmin":"min","tasmax":"max"}, inplace=True)

# # ---- LOAD SCALERS & SCALE FEATURES ----
# feat_scaler = joblib.load(os.path.join(CACHE_DIR, f"{STATION_NAME}_feat_scaler.save"))
# tgt_scaler  = joblib.load(os.path.join(CACHE_DIR, f"{STATION_NAME}_tgt_scaler.save"))
# features    = df[["min","max","doy_sin","doy_cos"]].values.astype(np.float32)
# X_scaled    = feat_scaler.transform(features)

# # ---- LOAD MODEL & PREDICT ----
# model = SimpleFC().to(DEVICE)
# model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE, weights_only=True))
# model.eval()
# with torch.no_grad():
#     X_tensor     = torch.tensor(X_scaled, dtype=torch.float32, device=DEVICE)
#     preds_scaled = model(X_tensor).cpu().numpy()
# preds = tgt_scaler.inverse_transform(preds_scaled)

# # ---- BUILD WIDE DF ----
# hours   = [f"H{h:02d}" for h in range(24)]
# wide_df = pd.DataFrame(preds, columns=hours, index=df["date"])
# wide_df.index.name = "date"
# wide_df = wide_df.reset_index()

# # ---- MELT TO LONG FORMAT ----
# long_df = wide_df.melt(
#     id_vars="date",
#     value_vars=hours,
#     var_name="hour_str",
#     value_name="temperature"
# )

# # ---- EXTRACT YEAR, MONTH, DAY, HOUR ----
# long_df["hour"] = long_df["hour_str"].str[1:].astype(int)
# ymd = long_df["date"].astype(str).str.split("-", expand=True).astype(int)
# long_df["year"], long_df["month"], long_df["day"] = ymd[0], ymd[1], ymd[2]

# # ---- SELECT & SORT COLUMNS ----
# long_df = long_df[["year","month","day","hour","temperature"]]
# long_df = long_df.sort_values(["year","month","day","hour"]).reset_index(drop=True)

# # ---- SAVE ----
# long_df.to_csv(OUTPUT_CSV, index=False)
# print(f"Saved long‑format hourly predictions to {OUTPUT_CSV}")


import os
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import joblib

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CACHE_DIR = "dperm_cache"
MODEL_PATH = "dfast_train.pt"

# ---- MODEL DEFINITION ----
class SimpleFC(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(4, 10)
        self.tanh = nn.Tanh()
        self.fc2 = nn.Linear(10, 24)
    def forward(self, x):
        return self.fc2(self.tanh(self.fc1(x)))

stations = [
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Ahmedabad_Gujarat.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Bangalore.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Barkheda_Madhya_Pradesh.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Charampa_Odisha.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Hyderabad.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Ind-Pak_Border_Rajasthan.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Kanyakumari.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Nepal-India_Border_Gandak_Barrage.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Parel_Mumbai_Maharastra.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp245_Pragati_Thermal_Power_Plant_Delhi.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Ahmedabad_Gujarat.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Bangalore.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Barkheda_Madhya_Pradesh.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Charampa_Odisha.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Hyderabad.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Ind-Pak_Border_Rajasthan.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Kanyakumari.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Nepal-India_Border_Gandak_Barrage.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Parel_Mumbai_Maharastra.csv",
    "/home/bel/Desktop/Abhitej SRIP/Russia_model_data/ssp585_Pragati_Thermal_Power_Plant_Delhi.csv"
]
output_csvs = [
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Ahmedabad(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Bangalore(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Barkheda_MP(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Charampa_Odisha(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Hyderabad(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Rajasthan(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Kanyakumari(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Gandak_Barrage(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Mumbai(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp245_Delhi(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Ahmedabad(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Bangalore(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Barkheda_MP(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Charampa_Odisha(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Hyderabad(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Rajasthan(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Kanyakumari(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Gandak_Barrage(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Mumbai(Rus).csv",
    "Future predicted data/Russia model/future_hourly_preds_ssp585_Delhi(Rus).csv",
]

station_names = [
    "1981-2022_NH-64-Amd_Final",
    "1981-2022_NH-75-Blr_Final",
    "1981-2022_NH-146-MP_Final",
    "1981-2022_NH-16-OD_Final",
    "1981-2022_NH-163-Hyd_Final",
    "1981-2022_NH-94-RJ_Final",
    "1981-2022_NH-44-TN_Final",
    "1981-2022_NH-64-Nepal_Final",
    "1981-2022_EEH-Mum_Final",
    "1981-2022_NH-44-Del_Final",
    "1981-2022_NH-64-Amd_Final",
    "1981-2022_NH-75-Blr_Final",
    "1981-2022_NH-146-MP_Final",
    "1981-2022_NH-16-OD_Final",
    "1981-2022_NH-163-Hyd_Final",
    "1981-2022_NH-94-RJ_Final",
    "1981-2022_NH-44-TN_Final",
    "1981-2022_NH-64-Nepal_Final",
    "1981-2022_EEH-Mum_Final",
    "1981-2022_NH-44-Del_Final" 
]

# ---- PREDICTION LOOP ----
model = SimpleFC().to(DEVICE)
model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE, weights_only=True))
model.eval()

for FUTURE_CSV, OUTPUT_CSV, STATION_NAME in zip(stations, output_csvs, station_names):
    print(f"Processing: {FUTURE_CSV}")
    
    # ---- LOAD & PREPROCESS FUTURE DAILY DATA ----
    df = pd.read_csv(FUTURE_CSV, usecols=["Year", "Month", "Day", "tasmax", "tasmin"])
    df["date"] = pd.to_datetime(df[["Year", "Month", "Day"]]).dt.date
    df["day_of_year"] = pd.to_datetime(df["date"]).dt.dayofyear
    df["days_in_year"] = pd.to_datetime(df["date"]).dt.is_leap_year.map({True: 366, False: 365})
    df["doy_sin"] = np.sin(2 * np.pi * df["day_of_year"] / df["days_in_year"])
    df["doy_cos"] = np.cos(2 * np.pi * df["day_of_year"] / df["days_in_year"])
    df.rename(columns={"tasmin": "min", "tasmax": "max"}, inplace=True)

    # ---- LOAD SCALERS & SCALE FEATURES ----
    feat_scaler = joblib.load(os.path.join(CACHE_DIR, f"{STATION_NAME}_feat_scaler.save"))
    tgt_scaler = joblib.load(os.path.join(CACHE_DIR, f"{STATION_NAME}_tgt_scaler.save"))
    features = df[["min", "max", "doy_sin", "doy_cos"]].values.astype(np.float32)
    X_scaled = feat_scaler.transform(features)

    # ---- PREDICT ----
    with torch.no_grad():
        X_tensor = torch.tensor(X_scaled, dtype=torch.float32, device=DEVICE)
        preds_scaled = model(X_tensor).cpu().numpy()
    preds = tgt_scaler.inverse_transform(preds_scaled)

    # ---- BUILD WIDE DF ----
    hours = [f"H{h:02d}" for h in range(24)]
    wide_df = pd.DataFrame(preds, columns=hours, index=df["date"])
    wide_df.index.name = "date"
    wide_df = wide_df.reset_index()

    # ---- MELT TO LONG FORMAT ----
    long_df = wide_df.melt(
        id_vars="date",
        value_vars=hours,
        var_name="hour_str",
        value_name="temperature"
    )

    # ---- EXTRACT YEAR, MONTH, DAY, HOUR ----
    long_df["hour"] = long_df["hour_str"].str[1:].astype(int)
    ymd = long_df["date"].astype(str).str.split("-", expand=True).astype(int)
    long_df["year"], long_df["month"], long_df["day"] = ymd[0], ymd[1], ymd[2]

    # ---- SELECT & SORT COLUMNS ----
    long_df = long_df[["year", "month", "day", "hour", "temperature"]]
    long_df = long_df.sort_values(["year", "month", "day", "hour"]).reset_index(drop=True)

    # ---- SAVE TO CSV ----
    os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)
    long_df.to_csv(OUTPUT_CSV, index=False)
    print(f"Saved: {OUTPUT_CSV}")