import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import time
from torch.amp import autocast

script_start_time = time.time()
CACHE_DIR = 'hybrid_cache1'
NEW_DATA_PATHS = ["1981-2022_NH-163-Hyd_Final.csv", "1981-2022_NH-44-Del_Final.csv"]
BATCH_SIZE = 128
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class RNNModel(nn.Module):
    def __init__(self, input_size=6, hidden_size=10, num_layers=1):
        super().__init__()
        self.rnn = nn.RNN(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, 24)
    def forward(self, x):
        x = x.unsqueeze(1)         # [B, 1, 6]
        out, _ = self.rnn(x)
        return self.fc(out[:, -1, :])
class TempDataset(torch.utils.data.Dataset):
    def __init__(self, X, Y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32)
    def __len__(self): return len(self.X)
    def __getitem__(self, i): return self.X[i], self.Y[i]


model = RNNModel().to(DEVICE)
model.load_state_dict(torch.load('hybrid_rnn1.pt', map_location=DEVICE, weights_only=True))
model.eval()
all_preds, all_trues = [], []
for path in NEW_DATA_PATHS:
    df = pd.read_csv(path)
    df['datetime']     = pd.to_datetime(df[['Year','Month','Day','Hour']])
    df.sort_values('datetime', inplace=True)
    df['date']         = df['datetime'].dt.date
    df['day_of_year']  = df['datetime'].dt.dayofyear
    df['days_in_year'] = df['datetime'].dt.is_leap_year.map({True:366, False:365})
    df['doy_sin']      = np.sin(2*np.pi * df['day_of_year'] / df['days_in_year'])
    df['doy_cos']      = np.cos(2*np.pi * df['day_of_year'] / df['days_in_year'])

    daily = df.groupby('date')['AirTemp'].agg(min='min', max='max')
    pivot = df.pivot(index='date', columns='Hour', values='AirTemp')
    dates = sorted(pivot.index)

    feats, trues = [], []
    prev_pred_min = prev_pred_max = 0.0

    for date in dates:
        if date not in daily.index:
            continue
        row_vals = pivot.loc[date]
        if row_vals.isnull().any():
            continue

        min_curr, max_curr = daily.loc[date]
        row0 = df[df['date'] == date].iloc[0]
        feat = [
            min_curr, max_curr,
            prev_pred_min, prev_pred_max,
            row0['doy_sin'], row0['doy_cos']
        ]
        tgt = row_vals.values.astype(np.float32)

        feats.append(feat)
        trues.append(tgt)
        feat_scaler = StandardScaler().fit(np.array(feats))
        tgt_scaler = StandardScaler().fit(np.array(trues))
        # update prev_pred via model
        scaled_feat = feat_scaler.transform([feat])
        with torch.no_grad():
            inp = torch.tensor(scaled_feat, dtype=torch.float32).to(DEVICE)
            with autocast(device_type='cuda'):
                scaled_pred = model(inp).cpu().numpy()
        pred_orig = tgt_scaler.inverse_transform(scaled_pred)[0]
        prev_pred_min, prev_pred_max = pred_orig.min(), pred_orig.max()

    # prepare loader
    X_eval = feat_scaler.transform(np.vstack(feats))
    Y_eval = tgt_scaler.transform(np.vstack(trues))
    eval_loader = DataLoader(TempDataset(X_eval, Y_eval),
                             batch_size=BATCH_SIZE, shuffle=False, num_workers=4, pin_memory=True, persistent_workers=True)

    # predict
    preds, truths = [], []
    with torch.no_grad():
        for xb, yb in eval_loader:
            xb = xb.to(DEVICE)
            with autocast(device_type='cuda'):
                out = model(xb)
            preds.append(out.cpu().numpy())
            truths.append(yb.numpy())

    p_s = np.vstack(preds)
    t_s = np.vstack(truths)
    p_o = tgt_scaler.inverse_transform(p_s)
    t_o = tgt_scaler.inverse_transform(t_s)
    all_preds.append(p_o)
    all_trues.append(t_o)

    # metrics
    mse = mean_squared_error(t_o, p_o)
    mae = mean_absolute_error(t_o, p_o)
    r2  = r2_score(t_o, p_o)

    print(f"\nResults for {os.path.basename(path)}:")
    print(f"  MSE: {mse:.4f}")
    print(f"  MAE: {mae:.4f}")
    print(f"  R² : {r2:.4f}")
all_preds = np.vstack(all_preds)
all_trues = np.vstack(all_trues)

overall_mse = mean_squared_error(all_trues, all_preds)
overall_mae = mean_absolute_error(all_trues, all_preds)
overall_r2  = r2_score(all_trues, all_preds)

print("\nOverall Metrics Across All New Stations:")
print(f"  MSE: {overall_mse:.4f}")
print(f"  MAE: {overall_mae:.4f}")
print(f"  R² : {overall_r2:.4f}")

script_end_time = time.time()
elapsed = script_end_time - script_start_time
print(f"\nEvaluation completed in {time.strftime('%H:%M:%S', time.gmtime(elapsed))}")
