

import os
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
from torch.amp import autocast
import matplotlib.pyplot as plt

script_start = time.time()

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
SEQUENCE_LENGTH = 1 

NEW_DATA_PATHS = [
    "1981-2022_NH-146-MP_Final.csv",
    "1981-2022_NH-163-Hyd_Final.csv"
]
CACHE_DIR = 'rnn1_cache'
 
class TempSequenceDataset(torch.utils.data.Dataset):
    def __init__(self, X_seq, X_static, Y):
        self.X_seq = torch.tensor(X_seq, dtype=torch.float32)
        self.X_static = torch.tensor(X_static, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32)
    def __len__(self): return len(self.X_seq)
    def __getitem__(self, i): return self.X_seq[i], self.X_static[i], self.Y[i]

class TemperatureRNN(nn.Module):
    def __init__(self, seq_input_size=2, static_input_size=2, hidden_size=10, num_layers=1, output_size=24):
        super().__init__()
        self.rnn = nn.RNN(seq_input_size, hidden_size, num_layers,
                          batch_first=True, dropout=0.2 if num_layers>1 else 0)
        self.fc1 = nn.Linear(hidden_size + static_input_size, output_size)
    def forward(self, seq_x, static_x):
        rnn_out, _ = self.rnn(seq_x)
        features = rnn_out[:, -1, :]
        combined = torch.cat([features, static_x], dim=1)
        return self.fc1(combined)
    
def create_sequences(df, SEQUENCE_LENGTH):
    df = df.sort_values('datetime').copy()
    df['date'] = df['datetime'].dt.date
    daily = df.groupby('date')['AirTemp'].agg(['min','max']).fillna(0)
    pivot = df.pivot(index='date', columns='Hour', values='AirTemp')
    df_daily = df.groupby('date').first().reset_index()
    df_daily['day_of_year'] = df_daily['datetime'].dt.dayofyear
    df_daily['days_in_year'] = df_daily['datetime'].dt.is_leap_year.map({True:366,False:365})
    df_daily['doy_sin'] = np.sin(2*np.pi*df_daily['day_of_year']/df_daily['days_in_year'])
    df_daily['doy_cos'] = np.cos(2*np.pi*df_daily['day_of_year']/df_daily['days_in_year'])
    seqs, stats, tars = [], [], []
    dates = sorted(pivot.index)
    for i in range(SEQUENCE_LENGTH, len(dates)):
        d = dates[i]
        if pivot.loc[d].isnull().any(): continue
        seq = []
        valid = True
        for j in range(SEQUENCE_LENGTH):
            pd0 = dates[i-SEQUENCE_LENGTH+j]
            if pd0 not in daily.index:
                valid = False; break
            seq.append(daily.loc[pd0].values)
        if not valid: continue
        row = df_daily[df_daily['date']==d]
        if row.empty: continue
        stats.append([row['doy_sin'].iloc[0], row['doy_cos'].iloc[0]])
        seqs.append(seq)
        tars.append(pivot.loc[d].values.astype(np.float32))
    return np.array(seqs), np.array(stats), np.array(tars)

# Load model
model = TemperatureRNN().to(DEVICE)
model.load_state_dict(torch.load("rnn_temperature_model1.pt", map_location=DEVICE, weights_only=True))
model.eval()
all_preds_total = []
all_trues_total = []
print("\n Evaluating New Stations")
for path in NEW_DATA_PATHS:
    station = os.path.splitext(os.path.basename(path))[0]
    print(f"\nStation: {station}")
    df = pd.read_csv(path)
    df['datetime'] = pd.to_datetime(df[['Year','Month','Day','Hour']])
    seq, stat, tar = create_sequences(df, SEQUENCE_LENGTH)
    if len(seq)==0:
        print("No valid data")
        continue
    # Fit station-specific scalers on entire data
    seq_scaler    = StandardScaler().fit(seq.reshape(-1,2))
    static_scaler = StandardScaler().fit(stat)
    target_scaler = StandardScaler().fit(tar)
    # Scale inputs
    X_seq_scaled  = seq_scaler.transform(seq.reshape(-1,2)).reshape(seq.shape)
    X_stat_scaled = static_scaler.transform(stat)
    Y_scaled      = target_scaler.transform(tar)
    # Predict
    ds = TempSequenceDataset(X_seq_scaled, X_stat_scaled, Y_scaled)
    loader = DataLoader(ds, batch_size=64, shuffle=False, pin_memory=True, num_workers=4)
    
    preds_scaled = []
    trues_scaled = []

    model.eval()
    with torch.no_grad():
        for xb, xs, yb in loader:
            xb, xs = xb.to(DEVICE), xs.to(DEVICE)
            with autocast(device_type='cuda' if torch.cuda.is_available() else 'cpu'):
                preds = model(xb, xs).cpu().numpy()
            preds_scaled.append(preds)
            trues_scaled.append(yb.numpy())
    preds_scaled = np.vstack(preds_scaled)
    trues_scaled  = np.vstack(trues_scaled)
    preds = target_scaler.inverse_transform(preds_scaled)
    trues = target_scaler.inverse_transform(trues_scaled)
    mse = mean_squared_error(trues, preds)
    mae = mean_absolute_error(trues, preds)
    r2  = r2_score(trues, preds)
    all_preds_total.append(preds)
    all_trues_total.append(trues)
    print(f"  MSE: {mse:.4f}")
    print(f"  MAE: {mae:.4f}")
    print(f"  R²:  {r2:.4f}")

    plt.figure(figsize=(8, 6))

# Flatten arrays
    true_flat = trues.flatten()
    pred_flat = preds.flatten()

# Clip negatives to zero so axes don't extend below 0
    true_plot = np.clip(true_flat, 0, None)
    pred_plot = np.clip(pred_flat, 0, None)

# Scatter
    plt.scatter(true_plot, pred_plot, alpha=0.6, s=1)

# Reference line & axis limits
    max_val = max(true_plot.max(), pred_plot.max())
    ax = plt.gca()
    ax.plot([0, max_val], [0, max_val], 'r--', lw=2, label='Reference Line')
    ax.set_xlim(0, 50)
    ax.set_ylim(0, 50)
    ax.set_aspect('equal', adjustable='box')

    ax.set_xticks([0, 10, 20, 30, 40, 50])
    ax.set_yticks([0, 10, 20, 30, 40, 50])
# -------------------------------------------------------------
    plt.xlabel('ERA5 Reanalysis data')
    plt.ylabel('Predicted Temperature')
    plt.title(f'R² = {r2:.4f}, MAE = {mae:.4f}°C')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(f'rnn_scatter_plot1_{os.path.basename(path)}.png',
            dpi=300, bbox_inches='tight')
    plt.close()

all_preds_arr = np.vstack(all_preds_total)
all_trues_arr = np.vstack(all_trues_total)
overall_mse = mean_squared_error(all_trues_arr, all_preds_arr)
overall_mae = mean_absolute_error(all_trues_arr, all_preds_arr)
overall_r2  = r2_score(all_trues_arr, all_preds_arr)

print("\nOverall Metrics Across All New Stations:")
print(f"  MSE: {overall_mse:.4f}")
print(f"  MAE: {overall_mae:.4f}")
print(f"  R² : {overall_r2:.4f}")
duration = time.time() - script_start
print(f"\nTotal eval time: {time.strftime('%H:%M:%S', time.gmtime(duration))}")
