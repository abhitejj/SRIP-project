import os
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import joblib

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CACHE_DIR = 'rnn1_cache'
MODEL_PATH = 'rnn_temperature_model1.pt'
SEQUENCE_LENGTH = 1  

class TemperatureRNN(nn.Module):
    def __init__(self, seq_input_size=2, static_input_size=2, hidden_size=10, num_layers=1, output_size=24):
        super().__init__()
        self.rnn = nn.RNN(seq_input_size, hidden_size, num_layers,
                          batch_first=True, dropout=0.2 if num_layers>1 else 0)
        self.fc1 = nn.Linear(hidden_size + static_input_size, output_size)
    def forward(self, seq_x, static_x):
        rnn_out, _ = self.rnn(seq_x)
        features = rnn_out[:, -1, :]
        combined = torch.cat([features, static_x], dim=1)
        return self.fc1(combined)
    
stations = [
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Ahmedabad_Gujarat.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Bangalore.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Barkheda_Madhya_Pradesh.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Charampa_Odisha.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Hyderabad.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Ind-Pak_Border_Rajasthan.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Kanyakumari.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Nepal-India_Border_Gandak_Barrage.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Parel_Mumbai_Maharastra.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp245_Pragati_Thermal_Power_Plant_Delhi.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Ahmedabad_Gujarat.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Bangalore.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Barkheda_Madhya_Pradesh.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Charampa_Odisha.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Hyderabad.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Ind-Pak_Border_Rajasthan.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Kanyakumari.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Nepal-India_Border_Gandak_Barrage.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Parel_Mumbai_Maharastra.csv",
    "/home/bel/Desktop/Abhitej SRIP/Australia_model_data/ssp585_Pragati_Thermal_Power_Plant_Delhi.csv",
]
output_csvs = [
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Ahmedabad(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Bangalore(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Barkheda_MP(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Charampa_Odisha(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Hyderabad(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Rajasthan(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Kanyakumari(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Gandak_Barrage(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Mumbai(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp245_Delhi(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Ahmedabad(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Bangalore(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Barkheda_MP(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Charampa_Odisha(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Hyderabad(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Rajasthan(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Kanyakumari(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Gandak_Barrage(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Mumbai(Aus).csv",
    "Future predicted data RNN/Australia model/future_hourly_preds_ssp585_Delhi(Aus).csv",
]
station_names = [
    "1981-2022_NH-64-Amd_Final",
    "1981-2022_NH-75-Blr_Final",
    "1981-2022_NH-146-MP_Final",
    "1981-2022_NH-16-OD_Final",
    "1981-2022_NH-163-Hyd_Final",
    "1981-2022_NH-94-RJ_Final",
    "1981-2022_NH-44-TN_Final",
    "1981-2022_NH-64-Nepal_Final",
    "1981-2022_EEH-Mum_Final",
    "1981-2022_NH-44-Del_Final",
    "1981-2022_NH-64-Amd_Final",
    "1981-2022_NH-75-Blr_Final",
    "1981-2022_NH-146-MP_Final",
    "1981-2022_NH-16-OD_Final",
    "1981-2022_NH-163-Hyd_Final",
    "1981-2022_NH-94-RJ_Final",
    "1981-2022_NH-44-TN_Final",
    "1981-2022_NH-64-Nepal_Final",
    "1981-2022_EEH-Mum_Final",
    "1981-2022_NH-44-Del_Final" 
]
model = TemperatureRNN().to(DEVICE)
model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE, weights_only=True))
model.eval()

def forecast_future_rnn(station_name, csv_path, output_path):
    print(f"\nForecasting for station: {station_name}")

    # ======================================================
    # Load future CMIP daily tasmin/tasmax data
    # ======================================================
    df = pd.read_csv(csv_path)
    df['date'] = pd.to_datetime(df[['Year', 'Month', 'Day']])
    df = df.sort_values('date').reset_index(drop=True)

    # ======================================================
    # Compute day-of-year sine and cosine
    # ======================================================
    df['day_of_year'] = df['date'].dt.dayofyear
    df['days_in_year'] = df['date'].dt.is_leap_year.map({True: 366, False: 365})
    df['doy_sin'] = np.sin(2 * np.pi * df['day_of_year'] / df['days_in_year'])
    df['doy_cos'] = np.cos(2 * np.pi * df['day_of_year'] / df['days_in_year'])

    # ======================================================
    # Load scalers for this station
    # ======================================================
    scaler_path = os.path.join(CACHE_DIR, f"{station_name}_scalers_consistent.pkl")
    if not os.path.exists(scaler_path):
        print(f"⚠️ Scaler not found for station {station_name} → Skipping.")
        return

    scalers = joblib.load(scaler_path)
    seq_scaler = scalers["seq_scaler"]
    stat_scaler = scalers["stat_scaler"]
    tar_scaler = scalers["tar_scaler"]

    # ======================================================
    # Sequential prediction loop (true RNN behavior)
    # ======================================================
    preds_all = []
    seq_buffer = []

    for i in range(len(df)):
        row = df.iloc[i]
        doy_feats = np.array([[row['doy_sin'], row['doy_cos']]], dtype=np.float32)

        # Maintain last SEQUENCE_LENGTH tasmin/tasmax pairs
        if len(seq_buffer) < SEQUENCE_LENGTH:
            seq_buffer.append([row['tasmin'], row['tasmax']])
        else:
            seq_buffer = seq_buffer[-(SEQUENCE_LENGTH-1):] + [[row['tasmin'], row['tasmax']]]

        seq_arr = np.array(seq_buffer[-SEQUENCE_LENGTH:], dtype=np.float32)
        seq_scaled = seq_scaler.transform(seq_arr.reshape(-1, 2)).reshape(1, SEQUENCE_LENGTH, 2)
        stat_scaled = stat_scaler.transform(doy_feats)

        seq_tensor = torch.tensor(seq_scaled, dtype=torch.float32).to(DEVICE)
        stat_tensor = torch.tensor(stat_scaled, dtype=torch.float32).to(DEVICE)

        with torch.no_grad():
            pred_scaled = model(seq_tensor, stat_tensor).cpu().numpy()

        # Inverse-transform and round to 2 decimals
        pred = tar_scaler.inverse_transform(pred_scaled)[0]
        pred = np.round(pred, 2)

        preds_all.append(pred)

    # ======================================================
    # Convert to long-format DataFrame
    # ======================================================
    hour_cols = [f"H{h:02d}" for h in range(24)]
    df_pred = pd.DataFrame(preds_all, columns=hour_cols)
    df_out = pd.concat([df[["Year", "Month", "Day"]], df_pred], axis=1)

    df_long = df_out.melt(id_vars=["Year", "Month", "Day"], 
                          var_name="Hour", 
                          value_name="temperature")
    df_long["Hour"] = df_long["Hour"].str.extract(r"H(\d+)").astype(int)

    # ======================================================
    # Save only long-format CSV
    # ======================================================
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df_long.to_csv(output_path, index=False)
    print(f"✅ Saved hourly future predictions (long format) → {output_path}")
for station_name, csv_path, output_path in zip(station_names, stations, output_csvs):
    try:
        forecast_future_rnn(station_name, csv_path, output_path)
    except Exception as e:
        print(f"Error while processing {station_name}: {e}")