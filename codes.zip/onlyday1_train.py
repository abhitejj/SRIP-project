#This is the code for the model to be used in the Paper
import os
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import itertools
from torch.amp import GradScaler, autocast
import random

script_start_time = time.time()

# PARAMETERS
DATA_PATHS = [
    "1981-2022_NH-16-OD_Final.csv",
    "1981-2022_NH-64-Nepal_Final.csv",
    "1981-2022_NH-44-TN_Final.csv",
    "1981-2022_NH-64-Amd_Final.csv",
    "1981-2022_NH-75-Blr_Final.csv",
    "1981-2022_NH-94-RJ_Final.csv",
    "1981-2022_NH-146-MP_Final.csv",
    "1981-2022_EEH-Mum_Final.csv",
 ]
BATCH_SIZE     = 128
EPOCHS_PER_PERM= 3
DEVICE         = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
if torch.cuda.is_available():
    # Get the default CUDA device (usually device 0)
    dev = torch.cuda.get_device_properties(DEVICE) 
    
    print("\n--- GPU Specifications ---")
    print(f"Name:          {dev.name}")
    print(f"Total Memory:  {dev.total_memory / (1024**3):.2f} GB")
    print(f"Compute Cap:   {dev.major}.{dev.minor} (Major: {dev.major}, Minor: {dev.minor})")
    print(f"Multi-Procs:   {dev.multi_processor_count}")
    print("----------------------------\n")
else:
    print("CUDA (GPU) is not available.")
CACHE_DIR      = 'dperm_cache'
os.makedirs(CACHE_DIR, exist_ok=True)

# DATASET
class TempDataset(torch.utils.data.Dataset):
    def __init__(self, X, Y=None):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32) if Y is not None else None
    def __len__(self): return len(self.X)
    def __getitem__(self, i):
        if self.Y is None:
            return self.X[i]
        return self.X[i], self.Y[i]

# MODEL
def create_model():
    class SimpleFC(nn.Module):
        def __init__(self):
            super().__init__()
            self.fc1 = nn.Linear(4, 10)
            self.tanh = nn.Tanh()
            self.fc2 = nn.Linear(10, 24)
        def forward(self, x):
            return self.fc2(self.tanh(self.fc1(x)))
    return SimpleFC().to(DEVICE)

# CREATE AND SAVE STATION-SPECIFIC SCALERS
for path in DATA_PATHS:
    df = pd.read_csv(path)
    df['datetime'] = pd.to_datetime(df[['Year','Month','Day','Hour']])
    df.sort_values('datetime', inplace=True)
    df['date'] = df['datetime'].dt.date
    df['day_of_year'] = df['datetime'].dt.dayofyear
    df['days_in_year'] = df['datetime'].dt.is_leap_year.map({True:366,False:365})
    df['doy_sin'] = np.sin(2*np.pi*df['day_of_year']/df['days_in_year'])
    df['doy_cos'] = np.cos(2*np.pi*df['day_of_year']/df['days_in_year'])

    daily = df.groupby('date')['AirTemp'].agg(min='min', max='max')
    pivot = df.pivot(index='date', columns='Hour', values='AirTemp').dropna()

    feats = np.vstack([[daily.loc[d, 'min'], daily.loc[d, 'max'], 
                       df.loc[df['date']==d, 'doy_sin'].iloc[0], 
                       df.loc[df['date']==d, 'doy_cos'].iloc[0]]
                      for d in pivot.index])
    tgts = pivot.values.astype(np.float32)
    sin = df.groupby('date')['doy_sin'].first()
    cos = df.groupby('date')['doy_cos'].first()
    cached = {
        'pivot': pivot,
        'daily': daily,
        'doy_sin': sin,
        'doy_cos': cos
    }
    station = os.path.splitext(os.path.basename(path))[0]
    joblib.dump(cached, os.path.join(CACHE_DIR, f"{station}_daily_data.pkl"))
    print(f"Cached daily data saved for: {station}")
    feat_scaler = StandardScaler().fit(feats)
    tgt_scaler  = StandardScaler().fit(tgts)
    joblib.dump(feat_scaler, os.path.join(CACHE_DIR, f'{station}_feat_scaler.save'))
    joblib.dump(tgt_scaler,  os.path.join(CACHE_DIR, f'{station}_tgt_scaler.save'))

def cache_perm(perm, perm_id):
    Xtr, Ytr, Xte, Yte = [], [], [], []

    for path in perm:
        station = os.path.splitext(os.path.basename(path))[0]
        cached_path = os.path.join(CACHE_DIR, f"{station}_daily_data.pkl")

        if not os.path.exists(cached_path):
            raise FileNotFoundError(f"Cached daily data not found for {station}")

        # Load cached daily data
        daily_data = joblib.load(cached_path)
        pivot = daily_data['pivot']
        daily = daily_data['daily']
        doy_sin = daily_data['doy_sin']
        doy_cos = daily_data['doy_cos']

        feat_scaler = joblib.load(os.path.join(CACHE_DIR, f'{station}_feat_scaler.save'))
        tgt_scaler  = joblib.load(os.path.join(CACHE_DIR, f'{station}_tgt_scaler.save'))

        dates = sorted(pivot.index)
        split = int(0.8 * len(dates))

        for i, d in enumerate(dates):
            if d not in daily.index or pivot.loc[d].isnull().any():
                continue
            f = [daily.loc[d, 'min'], daily.loc[d, 'max'],
                 doy_sin[d], doy_cos[d]]
            t = pivot.loc[d].values.astype(np.float32)

            fs = feat_scaler.transform([f])
            ts = tgt_scaler.transform([t])

            if i < split:
                Xtr.append(fs[0])
                Ytr.append(ts[0])
            else:
                Xte.append(fs[0])
                Yte.append((feat_scaler, tgt_scaler, f, t))

    Xtr = np.vstack(Xtr) if Xtr else np.array([])
    Ytr = np.vstack(Ytr) if Ytr else np.array([])
    Xte = np.vstack(Xte) if Xte else np.array([])
    Yte = np.array(Yte, dtype=object)

    np.savez(os.path.join(CACHE_DIR, f'dperm_{perm_id:02d}.npz'),
             Xtr=Xtr, Ytr=Ytr, Xte=Xte, Yte=Yte)
# TRAINING
model = create_model()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-2)
criterion = nn.MSELoss()
scaler = GradScaler()

random.seed(42)
perms = random.sample(list(itertools.permutations(DATA_PATHS)), 50)
for pid,perm in enumerate(perms,1):
    cf = os.path.join(CACHE_DIR, f'dperm_{pid:02d}.npz')
    if not os.path.exists(cf): 
        cache_perm(perm,pid)
    try:
        data = np.load(cf, allow_pickle=True)
        Xtr, Ytr = data['Xtr'], data['Ytr']
    except KeyError:
        print(f"[WARNING] Cache corrupt or incomplete: {cf}. Regenerating...")
        os.remove(cf)
        cache_perm(perm, pid)
        data = np.load(cf, allow_pickle=True)
        Xtr, Ytr = data['Xtr'], data['Ytr']
    if Xtr.size == 0 or Ytr.size == 0:
        print(f"[SKIP] Perm {pid:02d}: empty training set.")
        continue
    dl = DataLoader(TensorDataset(
        torch.tensor(Xtr, dtype=torch.float32),
        torch.tensor(Ytr, dtype=torch.float32)
    ), batch_size=BATCH_SIZE, shuffle=True, pin_memory=True, num_workers=4, persistent_workers=True)
    for epoch in range(EPOCHS_PER_PERM):
        model.train()
        for x,y in dl:
            x,y = x.to(DEVICE, non_blocking=True), y.to(DEVICE, non_blocking=True)
            optimizer.zero_grad()
            with autocast(device_type='cuda'):
                pred = model(x)
                loss = criterion(pred,y)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

# VALIDATION ON 20% HOLDOUT PER STATION
print("\nValidation per station")
all_preds, all_trues = [], []

for path in DATA_PATHS:
    station = os.path.splitext(os.path.basename(path))[0]
    cached_path = os.path.join(CACHE_DIR, f"{station}_daily_data.pkl")

    if not os.path.exists(cached_path):
        raise FileNotFoundError(f"Cached daily data not found for {station}")

    # Load cached data
    daily_data = joblib.load(cached_path)
    pivot = daily_data['pivot']
    daily = daily_data['daily']
    doy_sin = daily_data['doy_sin']
    doy_cos = daily_data['doy_cos']

    feat_scaler = joblib.load(os.path.join(CACHE_DIR, f'{station}_feat_scaler.save'))
    tgt_scaler  = joblib.load(os.path.join(CACHE_DIR, f'{station}_tgt_scaler.save'))

    dates = sorted(pivot.index)
    split = int(0.8 * len(dates))
    feats, tgts = [], []

    for i, d in enumerate(dates):
        if i < split or d not in daily.index or pivot.loc[d].isnull().any():
            continue
        f = [daily.loc[d, 'min'], daily.loc[d, 'max'], doy_sin[d], doy_cos[d]]
        t = pivot.loc[d].values.astype(np.float32)
        feats.append(f)
        tgts.append(t)

    feats = np.vstack(feats)
    tgts  = np.vstack(tgts)
    Xs = feat_scaler.transform(feats)

    ds = TempDataset(Xs)
    dl = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=False, pin_memory=True)

    preds = []
    model.eval()
    with torch.no_grad():
        for xb in dl:
            xb = xb.to(DEVICE)
            with autocast(device_type='cuda'):
                p = model(xb).cpu().numpy()
            preds.append(p)

    preds = np.vstack(preds)
    preds_orig = tgt_scaler.inverse_transform(preds)
    all_preds.append(preds_orig)
    all_trues.append(tgts)

    print(f"Station: {station}")
    print(" MSE:", f"{mean_squared_error(tgts, preds_orig):.4f}")
    print(" MAE:", f"{mean_absolute_error(tgts, preds_orig):.4f}")
    print(" R2 :", f"{r2_score(tgts, preds_orig):.4f}")

# OVERALL METRICS
all_p=np.vstack(all_preds); all_t=np.vstack(all_trues)
print("\nOverall Metrics:")
print(" MSE:", f"{mean_squared_error(all_t, all_p):.4f}")
print(" MAE:", f"{mean_absolute_error(all_t, all_p):.4f}")
print(" R2 :", f"{r2_score(all_t, all_p):.4f}")
torch.save(model.state_dict(), 'dfast_train.pt')
script_end_time=time.time()
print("Time taken", time.strftime('%H:%M:%S',time.gmtime(script_end_time-script_start_time)))

